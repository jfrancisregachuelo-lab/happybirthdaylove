# Birthday Surprise Website 🎉

## Files:
- index.html (main website)
- her-photo.jpg (your image - replace this)
- song.mp3 (your music - replace this)

## How to use:
1. Upload all files to GitHub repository
2. Enable GitHub Pages
3. Your site will go live as a link
